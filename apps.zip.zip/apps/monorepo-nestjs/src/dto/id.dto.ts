export class IdDto {
    id: number;
}